/**
 * ኩታበር ወረዳ ኮሙኒኬሽን — Google Apps Script web app
 * መረጃ በአንድ JSON ፋይል (Google Drive) ላይ ይቀመጣል፤ ሁሉም መሳሪያዎች ከዚሁ ይመሳሰላሉ።
 * ደንበኛው (index.html) የሚጠራው: api(body) → 'pull' | 'push'
 */
var DATA_FILE_NAME = 'kutaber-data.json';
var HTML_FILE_NAME = 'kutaber-index.html';

function doGet(e) {
  // index.html ከGoogle Drive ይነበባል (ወይም በ Apps Script ውስጥ ያለው "index" HTML ፋይል)
  var html = driveHtml_();
  var out = html ? HtmlService.createHtmlOutput(html) : HtmlService.createHtmlOutputFromFile('index');
  return out
    .setTitle('ኩታበር ወረዳ መንግስት ኮሙኒኬሽን')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function driveHtml_() {
  var names = ['index.html', 'index.html.txt'], best = null;
  for (var i = 0; i < names.length; i++) {
    var it = DriveApp.getFilesByName(names[i]);
    while (it.hasNext()) {
      var f = it.next();
      if (!best || f.getLastUpdated() > best.getLastUpdated()) best = f;
    }
  }
  return best ? best.getBlob().getDataAsString('UTF-8') : '';
}

// index.html ከሌላ ቦታ (hosted) ሲከፈት በ fetch ለመጠቀም
function doPost(e) {
  var out = api(e && e.postData ? e.postData.contents : '{}');
  return ContentService.createTextOutput(out).setMimeType(ContentService.MimeType.JSON);
}

// google.script.run.api(body) — JSON string ይመልሳል
function api(body) {
  var req, res;
  try {
    req = JSON.parse(body || '{}');
    if (req.action === 'pull') res = pull_();
    else if (req.action === 'push') res = push_(req);
    else res = { error: 'unknown action' };
  } catch (err) {
    res = { error: String(err) };
  }
  return JSON.stringify(res);
}

function pull_() {
  var d = read_();
  return { v: d.v, state: d.state };
}

function push_(req) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var cur = read_();
    if (Number(req.v) !== Number(cur.v)) return { conflict: true, v: cur.v };
    var next = { v: cur.v + 1, state: req.state, t: new Date().toISOString() };
    file_().setContent(JSON.stringify(next));
    return { v: next.v };
  } finally {
    lock.releaseLock();
  }
}

function read_() {
  var txt = file_().getBlob().getDataAsString('UTF-8');
  var d = txt ? JSON.parse(txt) : null;
  return d && typeof d.v === 'number' ? d : { v: 0, state: null };
}

function file_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('DATA_FILE_ID');
  if (id) {
    try { return DriveApp.getFileById(id); } catch (e) { /* ፋይሉ ከጠፋ እንደገና ይፈጠራል */ }
  }
  var f = DriveApp.createFile(DATA_FILE_NAME, JSON.stringify({ v: 0, state: null }), MimeType.PLAIN_TEXT);
  props.setProperty('DATA_FILE_ID', f.getId());
  return f;
}
